#include <stdio.h>

int main() {

  char x, y;

  printf("\nDigite um número:");
  scanf("%d",&x);
  y = 'a' + 5;
  printf("O valor da variável 'y' é:%d", y);
  return 0;
}