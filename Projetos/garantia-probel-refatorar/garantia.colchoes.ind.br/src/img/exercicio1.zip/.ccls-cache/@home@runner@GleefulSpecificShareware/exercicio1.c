#include <stdio.h>

int main() {

  float x, soma;

  printf("\nDigite um número:");
  scanf("%f",&x);
  soma = x + 5;
  printf("O valor da variável 'x' é:%f", soma);
  return 0;
}